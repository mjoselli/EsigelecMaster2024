package com.example.composableviews

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.composableviews.ui.theme.ComposableViewsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ComposableViewsTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    MyColumnList()
                }
            }
        }
    }
}
@Composable
fun MyLazyColumnList(){
    LazyColumn(){
        items(100){
            Text(text = "User $it")
        }
    }
}
@Composable
fun MyColumnList(){
    val scrollState = rememberScrollState()
    Column( Modifier.verticalScroll(scrollState)) {
        for (i in 1..100){
            Text(text = "User $i")
        }
    }
}
@Composable
fun GreentingsColumn(){
    Column(modifier = Modifier.background(Color.White),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally) {
        Row() {
            Greeting("Row 1")
            Greeting("Row 2")
            Greeting("Row 3")
        }
        Greeting("Mark 2")
        Greeting("Mark 3")
        Greeting("Mark")
    }
    Box(modifier = Modifier
        .background(Color.Blue)
        .size(20.dp, 20.dp)) {
        Text(text = "Hello")
    }
}
@Composable
fun Greeting(name: String) {
    Text(text = "Hello $name!")
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    ComposableViewsTheme {
        Greeting("Android")
    }
}