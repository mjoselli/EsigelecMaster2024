package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    var counter = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val textView = findViewById<TextView>(R.id.textView)
        textView.text = "counter: $counter"
        val editText = findViewById<EditText>(R.id.editText)
        val button = findViewById<Button>(R.id.button)
        button.text = "add to counter"
        button.setOnClickListener {
            val text = editText.text.toString()
            Toast.makeText(this,
                "I added $text",
                Toast.LENGTH_SHORT).show()
            val numberToAdd = text.toInt()
            counter += numberToAdd
            textView.text = "counter: $counter"
        }
    }
}