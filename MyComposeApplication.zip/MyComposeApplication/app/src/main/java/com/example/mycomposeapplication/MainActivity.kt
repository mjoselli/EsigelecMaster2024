package com.example.mycomposeapplication

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mycomposeapplication.ui.theme.MyComposeApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyComposeApplicationTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    Greeting("Android")
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String) {
    var count by remember { mutableStateOf(0) }
    var textValue by remember {
        mutableStateOf("")
    }
    val context = LocalContext.current
    Column{
        Counter(count = count) {
            count++
        }
        Spacer(modifier = Modifier.height(16.dp))
        MyText(text = "Hello $name!")
        Row{
            Text(text = "Bye $name!!!")
            MyText(text = "BYE!")
        }
        TextField(value = textValue, onValueChange = {
            textValue = it
        },
                label = {
                    Text(text = "Enter the text")
                })
        Button(onClick = {
            Toast
                .makeText(context,textValue,Toast.LENGTH_LONG)
                .show()
        }) {
            Text(text = "Click")
        }
    }
}
@Composable
fun MyText(text: String){
    Text(text = text,
        fontSize = 32.sp,
        fontWeight = FontWeight.Bold,
        color = Color.Blue,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .background(color = Color.Cyan)
            .border(3.dp, color = Color.Black)
            .padding(10.dp)
            .fillMaxWidth(.75f)
        )
}

@Composable
fun Counter(count: Int, onIncrement: () -> Unit) {
    Button(onClick = onIncrement) {
        Text("Clicked $count times")
    }
}


@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    MyComposeApplicationTheme {
        Greeting("Android")
    }
}