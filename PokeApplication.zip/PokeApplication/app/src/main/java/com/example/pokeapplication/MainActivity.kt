package com.example.pokeapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    lateinit var searchEditText: EditText
    lateinit var button: Button
    lateinit var imageView: ImageView
    lateinit var nameTextView: TextView
    lateinit var typeTextView: TextView
    lateinit var abilitiesTextView: TextView
    lateinit var pokemonData: PokemonData
    val pokemonService = Retrofit.Builder()
            .baseUrl("https://pokeapi.co/api/v2/")
        .addConverterFactory(
            GsonConverterFactory.create()
        ).build()
        .create(PokemonService::class.java)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        imageView = findViewById(R.id.imageView)
        nameTextView = findViewById(R.id.nameTextView)
        typeTextView = findViewById(R.id.typeTextView)
        abilitiesTextView = findViewById(R.id.abilitiesTextView)
        searchEditText = findViewById(R.id.searchEditText)
        button = findViewById(R.id.button)
        button.setOnClickListener {
            val searchText = searchEditText.text.toString()
            fetchPokemon(searchText)
        }
    }
    fun fetchPokemon(name: String){
       pokemonService.getPokemon(name)
           .enqueue(object: Callback<PokemonData>{
               override fun onResponse(call: Call<PokemonData>, response: Response<PokemonData>) {
                   if (response.isSuccessful){
                       val pokemon = response.body()!!
                       Glide.with(this@MainActivity)
                           .load(pokemon.sprites.front_default)
                           .into(imageView)
                       nameTextView.text= pokemon.name
                       typeTextView.text = pokemon.types.joinToString(","){ it.type.name}
                       abilitiesTextView.text = pokemon.abilities.joinToString(","){it.ability.name}
                   }
               }
               override fun onFailure(call: Call<PokemonData>, t: Throwable) {
                    Log.e("Pokemon",t.localizedMessage)
               }

           })
    }
}