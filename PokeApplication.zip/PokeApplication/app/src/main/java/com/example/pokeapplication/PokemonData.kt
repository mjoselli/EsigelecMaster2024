package com.example.pokeapplication

data class PokemonData(val name: String,
                       val sprites: PokemonSprite,
                       val types: List<PokemonType>,
                       val abilities: List<PokemonAbility>)

data class PokemonSprite(val front_default: String)

data class PokemonType(val type: PokemonTypeDetails)

data class PokemonTypeDetails(val name: String)

data class PokemonAbility(val ability: PokemonAbilityDetail)

data class PokemonAbilityDetail(val name: String)