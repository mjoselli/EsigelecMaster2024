package com.example.pokecomposerapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.pokecomposerapp.model.PokemonRepository
import com.example.pokecomposerapp.ui.theme.PokeComposerAppTheme
import com.example.pokecomposerapp.view.PokemonScreen
import com.example.pokecomposerapp.viewModel.PokemonViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    val pokemonViewModel = PokemonViewModel(PokemonRepository())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PokeComposerAppTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    PokemonScreen(viewModel = pokemonViewModel)
                }
            }
        }
    }
}




@Composable
fun Greeting(name: String) {
    Text(text = "Hello $name!")
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    PokeComposerAppTheme {
        Greeting("Android")
    }
}