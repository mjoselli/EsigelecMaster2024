package com.example.pokecomposerapp.model

import android.util.Log
import com.example.pokecomposerapp.PokemonData
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.lang.Exception

class PokemonRepository {
    private val pokemonService = Retrofit.Builder()
        .baseUrl("https://pokeapi.co/api/v2/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(PokemonService::class.java)
    suspend fun getPokemon(name: String): PokemonData?{
       return try{
           pokemonService.getPokemon(name).execute().body()
       }catch (e: Exception){
           Log.e("Pokemon",e.localizedMessage)
           null
       }
    }
}