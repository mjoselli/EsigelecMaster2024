package com.example.pokecomposerapp.model

import com.example.pokecomposerapp.PokemonData
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface PokemonService {
    @GET("pokemon/{name}")
    fun getPokemon(@Path("name") name: String)
            : Call<PokemonData>
}