package com.example.pokecomposerapp.view

import android.text.Layout
import androidx.compose.foundation.layout.*
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.pokecomposerapp.PokemonData

@Composable
fun PokemonCard (pokemonData: PokemonData){
    Card(modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)) {
        Column {
            AsyncImage(model = pokemonData.sprites.front_default,
                contentDescription = "an image of ${pokemonData.name}",
                modifier = Modifier.size(300.dp)
                                    .aspectRatio(1f)
                                    .align(alignment = Alignment.CenterHorizontally))
            Text(text = pokemonData.name)
            Text(text = "Types: " +
                    "${pokemonData.types.map { it.type.name }
                        .joinToString(", " )}")
            Text(text = "Abilities: " +
                    "${pokemonData.abilities.map { it.ability.name }
                        .joinToString(", " )}")
        }
    }
}