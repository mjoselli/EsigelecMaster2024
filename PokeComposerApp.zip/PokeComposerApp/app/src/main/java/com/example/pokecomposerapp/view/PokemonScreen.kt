package com.example.pokecomposerapp.view

import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.*
import com.example.pokecomposerapp.SearchBar
import com.example.pokecomposerapp.viewModel.PokemonViewModel
import kotlinx.coroutines.launch

@Composable
fun PokemonScreen(viewModel: PokemonViewModel){
    val state = viewModel.uiState.collectAsState()
    var searchText by remember {
        mutableStateOf("")
    }
    val scope = rememberCoroutineScope()
    Column() {
        SearchBar(value = searchText,
            onValueChange = {searchText = it},
            onSearch = {
                scope.launch {
                    viewModel.onSearchTextChanged(searchText)
                }
            })
        state.value.pokemonData?.let {
            PokemonCard(pokemonData = it)
        }
    }
}