package com.example.pokecomposerapp

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material.OutlinedButton
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SearchBar(value: String,
              onValueChange: (String) -> Unit,
              onSearch: () -> Unit){
    Row (Modifier.padding(16.dp)){
        TextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(text = "Search Pokemon") }
        )
        OutlinedButton(onClick = onSearch,
            Modifier.padding(8.dp)) {
            Text(text = "Search")
        }
    }
}