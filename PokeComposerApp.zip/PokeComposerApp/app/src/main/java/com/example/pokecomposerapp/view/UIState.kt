package com.example.pokecomposerapp.view

import com.example.pokecomposerapp.PokemonData

data class UIState (val pokemonData: PokemonData? = null)