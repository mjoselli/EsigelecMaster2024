package com.example.pokecomposerapp.viewModel

import android.util.Log
import androidx.lifecycle.ViewModel
import com.example.pokecomposerapp.model.PokemonRepository
import com.example.pokecomposerapp.view.UIState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext


class PokemonViewModel(private val repository: PokemonRepository): ViewModel() {
    private val _uiState = MutableStateFlow(UIState())
    val uiState = _uiState.asStateFlow()
    suspend fun onSearchTextChanged(text: String){
        withContext(Dispatchers.IO){
            try {
                val pokemonData = repository.getPokemon(text)
                if(pokemonData != null){
                    _uiState.value = _uiState.value
                        .copy(pokemonData = pokemonData)
                    Log.d("Pokemon","fetched ${pokemonData.name}")
                }else{
                    Log.e("Pokemon","no data $text")
                }
            }catch (e: Exception){
                Log.e("Pokemon",e.localizedMessage)
            }
        }
    }
}